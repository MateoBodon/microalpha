GPT Bundle

Generated: 20260126_204751Z
Repo: /home/codex/repos/microalpha
Ticket: TICKET-24d_ship-wrds-refresh-to-main

Contents:
- docs/_generated/repo_snapshot.md (if available)
- git_status.txt
- git_log.txt
- git_diff.patch (working tree)
- git_diff_cached.patch (staged)
- git_diff_stat.txt
- changed_files.txt
- ticket file (if present)
- small changed files (optional)
