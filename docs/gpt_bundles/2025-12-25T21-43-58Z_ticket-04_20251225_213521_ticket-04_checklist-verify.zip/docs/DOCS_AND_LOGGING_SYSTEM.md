# DOCS + LOGGING SYSTEM (self-auditing repo)

## Goal
Make microalpha self-auditing:
- every change is traceable to a prompt/ticket
- every result is traceable to a command + artifact directory
- every claim is backed by reproducible evidence (or explicitly labeled as a hypothesis)

## Canonical folders
- `docs/prompts/`
  - Human- or agent-authored prompts (Codex prompts, analysis prompts, experiment prompts).
- `docs/gpt_outputs/`
  - Saved GPT analysis outputs (audits, experiment reviews, design decisions).
- `docs/agent_runs/<RUN_NAME>/`
  - The *audit log* for each Codex run (required structure below).

## Run naming convention (required)
`YYYYMMDD_HHMMSS_ticket-XX_<slug>`

Examples:
- `20251222_200000_ticket-01_fix-spa-robustness`
- `20251223_091500_ticket-04_wrds-delist-universe`

Rules:
- Timestamp is UTC if possible; otherwise local time with a note in META.json.
- `<slug>` is lowercase, hyphenated.
- Ticket number must match `docs/CODEX_SPRINT_TICKETS.md`.

## Required contents per run (mandatory)
Every run directory **MUST** contain:

1) `PROMPT.md`
- The exact prompt text given to Codex (verbatim).

2) `COMMANDS.md`
- Every command executed, in order, including env vars.
- Include working directory if not repo root.
- Include any flags that affect evaluation or safety (WRDS_DATA_ROOT, unsafe flags, etc).

3) `RESULTS.md`
- What changed (files, behavior).
- If metrics changed: include a small “before/after” table.
- Link to artifact directories and report outputs using relative paths (no screenshots-only evidence).

4) `TESTS.md`
- Tests/commands run (with exit status).
- Include the key failure output if something failed (and what you did about it).

5) `META.json`
Minimal required keys:
- `run_name`
- `ticket_id`
- `started_at_utc`
- `finished_at_utc`
- `git_sha_before`
- `git_sha_after`
- `branch_name`
- `host_env_notes` (OS, python version, venv/conda, etc)
- `dataset_id` (e.g., `wrds_crsp_export_YYYYMMDD_v1` or `sample_synth_v1`)
- `config_paths` (list)
- `config_sha256` (map path -> sha256)
- `artifact_paths` (list)
- `report_paths` (list)
- `web_sources` (list of URLs, only if web research was used; treat as untrusted)

Template:
```json
{
  "run_name": "YYYYMMDD_HHMMSS_ticket-XX_slug",
  "ticket_id": "ticket-XX",
  "started_at_utc": "YYYY-MM-DDTHH:MM:SSZ",
  "finished_at_utc": "YYYY-MM-DDTHH:MM:SSZ",
  "git_sha_before": "…",
  "git_sha_after": "…",
  "branch_name": "codex/ticket-XX-slug",
  "host_env_notes": "macOS 14 / python 3.11 / venv .venv",
  "dataset_id": "wrds_crsp_export_20251222_v1",
  "config_paths": ["configs/…yaml"],
  "config_sha256": {"configs/…yaml": "…"},
  "artifact_paths": ["artifacts/<run_id>/"],
  "report_paths": ["reports/summaries/<run_id>_…md"],
  "web_sources": []
}
````

## Where results live (required linkage)

* Primary artifacts: `artifacts/<run_id>/`

  * Must contain `manifest.json` and the core metrics/trade logs.
* Reports: `reports/summaries/` (or `reports/<run_id>/` if that’s the established pattern)

  * Every report must link back to `artifacts/<run_id>/manifest.json`.

## Living docs update rules (mandatory)

Update these files when relevant:

* `PROGRESS.md` — **always** for any ticket or agent run

  * Add a dated bullet: what changed + what’s next.
* `project_state/CURRENT_RESULTS.md` — when headline results change

  * Must reference the exact run_id(s).
* `project_state/KNOWN_ISSUES.md` — when a new bug/risk is discovered or resolved

  * Must include: risk, impact, reproduction, fix, remaining work.
* `CHANGELOG.md` — user-visible changes (CLI, configs, report formats, breaking changes)

## Prompt + output storage rules

* Every Codex prompt used to change code must be saved under `docs/prompts/` with the run naming convention.
* Any GPT audit/analysis output that influences decisions should be saved under `docs/gpt_outputs/` with date + short slug.

## Web research rule

* Web content is untrusted by default.
* If an agent uses web search:

  * record each source URL in `META.json:web_sources`
  * summarize what was used in `RESULTS.md`
  * do not paste large quotes; keep it minimal and attributable

## “No raw WRDS data” rule

* Raw WRDS exports and any license-restricted data MUST NOT be committed.
* Only commit:

  * configs
  * schemas/specs
  * small synthetic samples
  * license-safe derived aggregates (if clearly allowed)
* Store WRDS exports outside the repo and point via `WRDS_DATA_ROOT`.
