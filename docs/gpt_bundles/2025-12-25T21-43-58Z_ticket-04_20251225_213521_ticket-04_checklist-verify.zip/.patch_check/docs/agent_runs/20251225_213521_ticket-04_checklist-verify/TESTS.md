# Tests

- make test-fast (pass; 111 passed, 1 skipped; warnings: ExecModelCfg.aln deprecation; analytics FutureWarning)
- pytest -q tests/test_no_lookahead.py (pass; 3 passed)
