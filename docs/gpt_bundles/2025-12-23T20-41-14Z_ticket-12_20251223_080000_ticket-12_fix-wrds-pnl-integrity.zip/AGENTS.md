# AGENTS.md — microalpha

This file defines non-negotiable working agreements for any agent (Codex CLI/IDE/Cloud) operating in this repo.

## Stop-the-line rules
Agents MUST stop and fix validity before anything else if any of these are true:
- Any evaluation introduces lookahead/leakage (e.g., same-day execution without explicit unsafe labeling).
- Universe construction is survivorship-biased or not point-in-time.
- Holdout is used (directly or indirectly) for tuning/selection.
- SPA/reality-check is silently skipped or crashes and results are still presented as headline.
- Metrics/results are claimed without executable evidence (commands + artifacts).

Agents MUST NOT:
- fabricate metrics, charts, tables, or “it improved” claims
- “massage” protocols to improve Sharpe (p-hacking)
- commit raw WRDS data or any license-restricted dataset

## Default workflow for any ticket
1) Inspect repo + relevant docs (no long pre-plan).
2) Implement minimal changes needed for the ticket.
3) Run the minimal sufficient tests.
4) Generate/refresh artifacts only if needed.
5) Write run logs under `docs/agent_runs/<RUN_NAME>/` (required set of files).
6) Update `PROGRESS.md` and any relevant living docs.
7) Commit on a feature branch with “Tests:” in commit body.

## How to run tests / builds (preferred)
- Discover Make targets:
  - `make help` (if available) or open `make_targets.txt`
- Typical commands used in this repo:
  - `pytest -q`
  - `make sample`
  - `make wfv`
  - `make report`
  - `make report-wfv`
  - WRDS-only (requires `WRDS_DATA_ROOT`):
    - `WRDS_DATA_ROOT=/path/to/wrds make wfv-wrds`
    - `WRDS_DATA_ROOT=/path/to/wrds make report-wrds`
    - `WRDS_DATA_ROOT=/path/to/wrds make test-wrds`

If a command doesn’t exist, do not invent a replacement silently:
- search the Makefile / CLI help (`microalpha --help`)
- update docs to reflect the real command you used

## Documentation protocol (mandatory)
Follow `docs/DOCS_AND_LOGGING_SYSTEM.md`.

Minimum required per run:
- `docs/prompts/<RUN_NAME>_ticket-XX_<slug>.md` (prompt used)
- `docs/agent_runs/<RUN_NAME>/PROMPT.md`
- `docs/agent_runs/<RUN_NAME>/COMMANDS.md`
- `docs/agent_runs/<RUN_NAME>/RESULTS.md`
- `docs/agent_runs/<RUN_NAME>/TESTS.md`
- `docs/agent_runs/<RUN_NAME>/META.json`

Living docs:
- Update `PROGRESS.md` on every run.
- Update `project_state/CURRENT_RESULTS.md` only when headline results change.
- Update `project_state/KNOWN_ISSUES.md` when bugs/risks are found/fixed.
- Update `CHANGELOG.md` for user-visible changes.

## Data policy (WRDS)
- Raw WRDS exports and any licensed datasets MUST NOT be committed.
- Store WRDS data outside the repo and reference it via `WRDS_DATA_ROOT`.
- Only commit license-safe:
  - synthetic samples
  - schemas/specs
  - tiny derived aggregates if clearly permitted
- If you need a “real-data smoke” in CI, use a cached, license-safe derived mini-sample (must be explicitly approved and documented).

## Branch + commit policy
- Use feature branches: `codex/ticket-XX-<slug>` or `dev/ticket-XX-<slug>`
- Commit message must start with `ticket-XX: ...`
- Commit body must include:
  - `Tests: ...`
  - `Artifacts: ...`
  - `Docs: ...`
- No direct commits to `main`.

## If uncertain (don’t spam questions)
- Make assumptions explicit in the run log (RESULTS.md + META.json).
- Prefer the smallest change that improves validity.
- If blocked, leave a clear TODO with reproduction steps and update KNOWN_ISSUES.md.
